/* Program metadata used by the homepage and practical detail view.
   The C++ source files are stored separately in the programs/ folder. */
window.DS_PROGRAMS = [
  {
    id: "selection-sort",
    number: "01",
    title: "Selection Sort",
    topic: "SORTING",
    shortDescription: "Sort a list of numbers in ascending order by repeatedly selecting the smallest remaining element.",
    description: "Selection Sort repeatedly searches the unsorted part of the array for its smallest value and swaps that value into the next correct position.",
    structure: "Array",
    algorithm: [
      "Read the number of elements and the array values.",
      "For each position from the beginning to the second-last element, assume that position contains the smallest value.",
      "Scan the remaining elements and update the index of the smallest value.",
      "Swap the current element with the smallest element found.",
      "Display the sorted array."
    ],
    complexity: { time: "O(n²)", space: "O(1)" },
    sampleInput: "5\n64 25 12 22 11",
    sampleOutput: "The sorted elements using the Selection Sort technique are:\n11 12 22 25 64",
    source: "programs/01-selection-sort.cpp"
  },
  {
    id: "bubble-sort",
    number: "02",
    title: "Bubble Sort",
    topic: "SORTING",
    shortDescription: "Sort an array by comparing adjacent values and swapping them when they are out of order.",
    description: "Bubble Sort repeatedly compares neighboring elements. After each pass, the largest remaining value moves toward the end of the array.",
    structure: "Array",
    algorithm: [
      "Read the number of elements and the array values.",
      "Perform passes through the array.",
      "Compare each element with the element next to it.",
      "Swap adjacent elements if the left element is greater.",
      "Repeat until the passes are complete, then display the array."
    ],
    complexity: { time: "O(n²)", space: "O(1)" },
    sampleInput: "5\n5 1 4 2 8",
    sampleOutput: "The sorted elements using the Bubble Sort technique are:\n1 2 4 5 8",
    source: "programs/02-bubble-sort.cpp"
  },
  {
    id: "linear-search",
    number: "03",
    title: "Linear Search",
    topic: "SEARCHING",
    shortDescription: "Find a requested value by checking array elements one at a time from the beginning.",
    description: "Linear Search checks each array value in sequence until the target is found. The given program reports the first matching position using one-based numbering.",
    structure: "Array",
    algorithm: [
      "Read the number of elements and the array values.",
      "Read the search key.",
      "Check each array element from index zero.",
      "If an element matches the key, save its index and stop searching.",
      "Display the position if found; otherwise display that the element was not found."
    ],
    complexity: { time: "O(n)", space: "O(1)" },
    sampleInput: "5\n10 20 30 40 50\n30",
    sampleOutput: "Element found at position 3.",
    source: "programs/03-linear-search.cpp"
  },
  {
    id: "towers-of-hanoi",
    number: "04",
    title: "Towers of Hanoi",
    topic: "RECURSION",
    shortDescription: "Print the sequence of moves needed to move disks between three towers using recursion.",
    description: "The recursive solution moves n−1 disks to the auxiliary tower, moves the largest disk to the destination, and then moves the n−1 disks onto the destination.",
    structure: "Recursion",
    algorithm: [
      "If there is one disk, print the move from the source tower to the destination tower.",
      "Move n−1 disks from source to auxiliary using destination as temporary storage.",
      "Print the move of disk n from source to destination.",
      "Move n−1 disks from auxiliary to destination using source as temporary storage."
    ],
    complexity: { time: "O(2ⁿ)", space: "O(n) recursive call stack" },
    sampleInput: "3",
    sampleOutput: "Steps to solve Towers of Hanoi:\nMove Disk 1 from A to C\nMove Disk 2 from A to B\nMove Disk 1 from C to B\nMove Disk 3 from A to C\nMove Disk 1 from B to A\nMove Disk 2 from B to C\nMove Disk 1 from A to C",
    source: "programs/04-towers-of-hanoi.cpp"
  },
  {
    id: "dynamic-array-min-max",
    number: "05",
    title: "Dynamic Array — Smallest and Largest",
    topic: "ARRAYS",
    shortDescription: "Allocate an array dynamically and find its minimum and maximum values.",
    description: "This program creates an integer array using dynamic memory allocation, traverses it to determine the smallest and largest values, then releases the allocated memory.",
    structure: "Dynamic Array",
    algorithm: [
      "Read the required array size.",
      "Allocate memory dynamically for the integer array.",
      "Read all array elements.",
      "Initialize min and max using the first array element.",
      "Traverse the array and update min or max when a smaller or larger value is found.",
      "Display the maximum and minimum elements.",
      "Release the dynamically allocated array using delete[]."
    ],
    complexity: { time: "O(n)", space: "O(n)" },
    sampleInput: "5\n12 7 25 3 18",
    sampleOutput: "The maximum element in the array is: 25\nThe minimum element in the array is: 3",
    source: "programs/05-dynamic-array-min-max.cpp"
  }
];

/* Loads the chosen practical information and source code */
(() => {
  const container = document.getElementById("practical-content");
  const programs = window.DS_PROGRAMS || [];
  const params = new URLSearchParams(window.location.search);
  const selected = programs.find((p) => p.id === params.get("id"));

  if (!container) return;

  if (!selected) {
    container.innerHTML = `
      <div class="not-found">
        <h2>Practical not found</h2>
        <p>The program link may be incorrect. Return to the homepage and choose a practical.</p>
        <p><a class="button button-primary" href="index.html#practicals">Browse practicals</a></p>
      </div>`;
    document.title = "Practical not found | DS LAB";
    return;
  }

  document.title = `${selected.title} | DS LAB`;
  const steps = selected.algorithm.map((step) => `<li>${step}</li>`).join("");

  container.innerHTML = `
    <section class="detail-hero">
      <p class="eyebrow">PRACTICAL ${selected.number} · ${selected.topic}</p>
      <h1>${selected.title}</h1>
      <p>${selected.description}</p>
      <div class="detail-tags">
        <span class="detail-tag">Data structure: ${selected.structure}</span>
        <span class="detail-tag">C++</span>
      </div>
    </section>
    <div class="detail-grid">
      <div>
        <section class="content-panel">
          <h2>Algorithm</h2>
          <ol class="algorithm-list">${steps}</ol>
        </section>
        <section class="content-panel">
          <h2>Complexity</h2>
          <table class="complexity-table">
            <thead><tr><th>Type</th><th>Complexity</th></tr></thead>
            <tbody>
              <tr><td>Time</td><td>${selected.complexity.time}</td></tr>
              <tr><td>Space</td><td>${selected.complexity.space}</td></tr>
            </tbody>
          </table>
        </section>
        <section class="content-panel">
          <h2>Sample run</h2>
          <div class="sample-box"><h3>Input</h3><pre>${selected.sampleInput}</pre></div>
          <div class="sample-box"><h3>Expected output</h3><pre>${selected.sampleOutput}</pre></div>
          <p class="notice">Sample input/output is an illustrative example based on the program logic. Your actual run may differ when you enter different values.</p>
        </section>
      </div>
      <div>
        <section class="content-panel code-panel">
          <div class="code-header"><span>C++ SOURCE · ${selected.source.split("/").pop()}</span><button class="copy-button" id="copy-code" type="button">Copy code</button></div>
          <pre class="code-source"><code id="source-code">Loading source code…</code></pre>
        </section>
        <p class="notice">This website displays C++ code. To execute it, compile the .cpp file with a C++ compiler on your computer.</p>
      </div>
    </div>
  `;

  const codeElement = document.getElementById("source-code");
  fetch(selected.source)
    .then((response) => {
      if (!response.ok) throw new Error(`Could not load source (${response.status})`);
      return response.text();
    })
    .then((code) => {
      codeElement.textContent = code.trimEnd();
      document.getElementById("copy-code").addEventListener("click", async () => {
        const button = document.getElementById("copy-code");
        try {
          await navigator.clipboard.writeText(code);
          button.textContent = "Copied!";
        } catch (error) {
          const temporary = document.createElement("textarea");
          temporary.value = code;
          temporary.style.position = "fixed";
          temporary.style.opacity = "0";
          document.body.appendChild(temporary);
          temporary.select();
          document.execCommand("copy");
          temporary.remove();
          button.textContent = "Copied!";
        }
        window.setTimeout(() => { button.textContent = "Copy code"; }, 1600);
      });
    })
    .catch((error) => {
      codeElement.textContent = error.message + ". Open this project using a local web server (such as VS Code Live Server) or use the GitHub Pages version.";
      codeElement.classList.add("code-error");
      const button = document.getElementById("copy-code");
      button.disabled = true;
    });
})();

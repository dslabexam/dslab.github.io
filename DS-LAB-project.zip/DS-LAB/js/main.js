/* Homepage card rendering and search */
(() => {
  const programs = window.DS_PROGRAMS || [];
  const grid = document.getElementById("program-grid");
  const search = document.getElementById("program-search");
  const count = document.getElementById("visible-count");
  const total = document.getElementById("program-count");
  const empty = document.getElementById("empty-state");

  if (!grid || !search) return;

  const cardHTML = (program) => `
    <a class="program-card" href="practical.html?id=${encodeURIComponent(program.id)}">
      <div class="card-top">
        <span class="program-number">PRACTICAL ${program.number}</span>
        <span class="topic-tag">${program.topic}</span>
      </div>
      <h3>${program.title}</h3>
      <p>${program.shortDescription}</p>
      <div class="card-link">View practical <span aria-hidden="true">→</span></div>
    </a>
  `;

  function render(query = "") {
    const normalized = query.trim().toLowerCase();
    const matches = programs.filter((p) =>
      [p.title, p.topic, p.shortDescription, p.description, p.structure]
        .join(" ")
        .toLowerCase()
        .includes(normalized)
    );
    grid.innerHTML = matches.map(cardHTML).join("");
    count.textContent = String(matches.length).padStart(2, "0");
    total.textContent = String(programs.length).padStart(2, "0");
    empty.hidden = matches.length !== 0;
    grid.hidden = matches.length === 0;
  }

  search.addEventListener("input", () => render(search.value));
  render();

  // Keyboard shortcut: "/" focuses the search box unless typing in a field.
  document.addEventListener("keydown", (event) => {
    if (event.key === "/" && !["INPUT", "TEXTAREA"].includes(document.activeElement.tagName)) {
      event.preventDefault();
      search.focus();
    }
  });
})();

#include <iostream>
using namespace std;

int main() {
    int a[20], n, key, pos = -1, i;

    cout << "Enter the number of elements: ";
    cin >> n;
    cout << "Enter " << n << " elements:" << endl;
    for (i = 0; i < n; i++) {
        cin >> a[i];
    }

    cout << "Enter the element to be searched: ";
    cin >> key;

    for (i = 0; i < n; i++) {
        if (a[i] == key) {
            pos = i;
            break;
        }
    }

    if (pos != -1)
        cout << "Element found at position " << pos + 1 << "." << endl;
    else
        cout << "Element not found in the list." << endl;

    return 0;
}

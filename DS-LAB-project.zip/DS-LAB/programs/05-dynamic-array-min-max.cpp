#include <iostream>
using namespace std;

int main() {
    int n, i, *arr, max, min;

    cout << "Enter the size of the array: ";
    cin >> n;

    arr = new int[n];

    cout << "Enter the array elements:" << endl;
    for (i = 0; i < n; i++) {
        cin >> arr[i];
    }

    min = arr[0];
    max = arr[0];

    for (i = 0; i < n; i++) {
        if (arr[i] < min) {
            min = arr[i];
        }
        if (arr[i] > max) {
            max = arr[i];
        }
    }

    cout << "The maximum element in the array is: " << max << endl;
    cout << "The minimum element in the array is: " << min << endl;

    delete[] arr;
    return 0;
}

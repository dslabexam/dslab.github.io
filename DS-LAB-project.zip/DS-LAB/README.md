# DS LAB — Data Structures Practicals

A responsive static website for learning and reviewing college C++ Data Structures practical programs.

## Programs included

1. Selection Sort
2. Bubble Sort
3. Linear Search
4. Towers of Hanoi
5. Dynamic Array — Smallest and Largest Element

## Features

- Responsive homepage and practical cards
- Search by program name, topic, or description
- Individual practical detail pages
- Algorithm steps and complexity
- C++ source files with copy-code button
- Sample input/output
- Static-site compatible with GitHub Pages

## Project structure

```text
DS-LAB/
├── index.html
├── practical.html
├── README.md
├── css/
│   └── style.css
├── js/
│   ├── main.js
│   └── practical.js
├── data/
│   └── programs.js
└── programs/
    ├── 01-selection-sort.cpp
    ├── 02-bubble-sort.cpp
    ├── 03-linear-search.cpp
    ├── 04-towers-of-hanoi.cpp
    └── 05-dynamic-array-min-max.cpp
```

## Run the website locally

Because the practical detail page loads `.cpp` source files using `fetch()`, open the folder through a local web server instead of opening the HTML file directly with `file://`.

### VS Code + Live Server

1. Open this folder in Visual Studio Code.
2. Install the **Live Server** extension.
3. Right-click `index.html`.
4. Choose **Open with Live Server**.

The website should open in your browser.

## Compile C++ programs

Use a C++ compiler such as MinGW-w64. In a terminal opened in the project folder, compile a program:

```bash
g++ programs/01-selection-sort.cpp -o selection-sort
```

Run on Windows:

```bash
selection-sort.exe
```

On Linux/macOS:

```bash
./selection-sort
```

Repeat with the other source files, changing the filename and executable name.

## Publish with GitHub Pages

1. Create a GitHub repository and upload/push the complete project.
2. In the repository, open **Settings → Pages**.
3. Under the build/deployment section, select **Deploy from a branch**.
4. Select the `main` branch and `/ (root)` folder.
5. Save and wait for the published URL to appear.

GitHub Pages hosts static files. It does not compile or execute C++ programs or host a C++ backend. This website presents source code and sample runs only.

## Source note

The C++ programs were transferred from the supplied `Index.html` reference. The Towers of Hanoi HTML-escaped symbol issue was normalized so the C++ source is valid and displays correctly; the algorithm was not changed. Sample inputs/outputs and explanatory algorithm text are examples prepared from the program logic, not separately supplied lecturer output sheets.
